import "prismjs";
import "prism-lua";

function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
 }

function simpleLuaCorrector(code) {
    let correctedCode = code;
    const errors = [];

    // Rule 1: `if x = y then` -> `if x == y then`
    let newCode = correctedCode.replace(/\bif\s+(.+?)\s*=\s*([^=].*?)\s+then/g, 'if $1 == $2 then');
    if (newCode !== correctedCode) {
        errors.push("Detectado uso de <code>=</code> em uma condição <code>if</code>. O correto para comparação é <code>==</code>.");
        correctedCode = newCode;
    }

    // Rule 2: `else if` -> `elseif`
    newCode = correctedCode.replace(/\belse\s+if\b/g, 'elseif');
    if (newCode !== correctedCode) {
        errors.push("Detectado uso de <code>else if</code>. Em Lua, a forma correta é <code>elseif</code>.");
        correctedCode = newCode;
    }

    // Rule 3: `!=` -> `~=`
    newCode = correctedCode.replace(/!=/g, '~=');
    if (newCode !== correctedCode) {
        errors.push("Detectado uso do operador de desigualdade <code>!=</code>. Em Lua, o correto é <code>~=</code>.");
        correctedCode = newCode;
    }

    // Rule 4: C-style comments `//` -> `--`
    newCode = correctedCode.replace(/^\s*(\/\/.*)/gm, '--$1');
    if (newCode !== correctedCode) {
        errors.push("Detectado uso de comentários com <code>//</code>. Em Lua, comentários de linha única são feitos com <code>--</code>.");
        correctedCode = newCode;
    }

    return { correctedCode, errors };
}

document.addEventListener('DOMContentLoaded', () => {
    const navButtons = document.querySelectorAll('nav button');
    const tabContents = document.querySelectorAll('.tab-content');

    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabId = button.dataset.tab;

            // Update button active state
            navButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            // Update content visibility
            tabContents.forEach(content => {
                if (content.id === tabId) {
                    content.classList.add('active');
                } else {
                    content.classList.remove('active');
                }
            });

            // Re-run Prism highlighting for the newly visible tab
            Prism.highlightAll();
        });
    });

    // Code copy functionality
    const copyButtons = document.querySelectorAll('.copy-btn');
    copyButtons.forEach(button => {
        button.addEventListener('click', () => {
            const codeBlock = button.previousElementSibling.querySelector('code');
            const codeText = codeBlock.innerText;

            navigator.clipboard.writeText(codeText).then(() => {
                button.textContent = 'Copiado!';
                setTimeout(() => {
                    button.textContent = 'Copiar Código';
                }, 2000);
            }).catch(err => {
                console.error('Falha ao copiar: ', err);
                button.textContent = 'Erro!';
                 setTimeout(() => {
                    button.textContent = 'Copiar Código';
                }, 2000);
            });
        });
    });

    // AI Script Corrector
    const fixCodeBtn = document.getElementById('fix-code-btn');
    const userScriptInput = document.getElementById('user-lua-script');
    const aiResponseArea = document.getElementById('ai-response-area');

    if (fixCodeBtn) {
        fixCodeBtn.addEventListener('click', () => {
            const originalCode = userScriptInput.value;
            if (originalCode.trim() === '') {
                aiResponseArea.innerHTML = `
                    <div class="chat-bubble ai">
                        <p>Por favor, cole um script na área de texto para que eu possa analisar.</p>
                    </div>
                `;
                return;
            }

            // Show "thinking" message
            aiResponseArea.innerHTML = `
                <div class="chat-bubble ai">
                    <p>Analisando seu código... 🧠</p>
                </div>
            `;
            
            // Simulate AI delay
            setTimeout(() => {
                const { correctedCode, errors } = simpleLuaCorrector(originalCode);

                let responseHTML = '<div class="chat-bubble ai">';

                if (errors.length === 0) {
                    responseHTML += "<h4>Nenhum erro comum detectado! ✅</h4>";
                    responseHTML += "<p>Parece que seu código não possui os erros simples que eu consigo detectar. Aqui está seu código original formatado:</p>";
                } else {
                    responseHTML += "<h4>Análise completa! Encontrei alguns pontos para melhorar:</h4><ul>";
                    errors.forEach(error => {
                        responseHTML += `<li>${error}</li>`;
                    });
                    responseHTML += "</ul><h4>Código Corrigido:</h4>";
                }

                responseHTML += `<pre><code class="language-lua">${escapeHtml(correctedCode)}</code></pre>`;
                responseHTML += '</div>';

                aiResponseArea.innerHTML = responseHTML;
                Prism.highlightAll();

            }, 1500); // 1.5 second delay
        });
    }

    // Initial Prism.js highlighting for the default active tab
    Prism.highlightAll();
});